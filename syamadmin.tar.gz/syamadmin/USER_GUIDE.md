# Panduan Penggunaan SyamAdmin

**Versi:** 1.0  
**Terakhir diperbarui:** Mei 2026  
**Platform:** Ubuntu 22.04 LTS (VPS)

SyamAdmin adalah AI sysadmin agent yang mengelola server Ubuntu 22.04 secara otomatis melalui Telegram. Dari setup awal clean install hingga production-ready LEMP stack, monitoring real-time, security hardening, dan manajemen site — semua dikendalikan lewat chat Telegram.

---

## Daftar Isi

1. [Prasyarat](#1-prasyarat)
2. [Instalasi](#2-instalasi)
3. [Konfigurasi](#3-konfigurasi)
4. [Menjalankan Agent](#4-menjalankan-agent)
5. [Perintah Telegram — Referensi Lengkap](#5-perintah-telegram--referensi-lengkap)
6. [Alur Kerja Umum](#6-alur-kerja-umum)
7. [Sistem Monitoring & Alert](#7-sistem-monitoring--alert)
8. [Keamanan & Hardening](#8-keamanan--hardening)
9. [Manajemen Site & SSL](#9-manajemen-site--ssl)
10. [Backup & Restore](#10-backup--restore)
11. [AI Brain — Perintah Natural Language](#11-ai-brain--perintah-natural-language)
12. [Struktur File & Direktori](#12-struktur-file--direktori)
13. [Troubleshooting](#13-troubleshooting)
14. [Keamanan Agent](#14-keamanan-agent)
15. [Tips Operasional](#15-tips-operasional)

---

## 1. Prasyarat

Sebelum menginstall SyamAdmin, pastikan Anda memiliki:

**Server:**

- VPS dengan Ubuntu 22.04 LTS (fresh install atau existing)
- Akses root (SSH)
- Minimal 1 GB RAM, 1 vCPU, 20 GB disk
- Koneksi internet aktif

**Akun & Token:**

- **Telegram Bot Token** — dibuat melalui [@BotFather](https://t.me/BotFather) di Telegram
- **Telegram User ID** — dapatkan dari [@userinfobot](https://t.me/userinfobot) atau [@RawDataBot](https://t.me/RawDataBot)
- **Anthropic API Key** *(opsional)* — dari [console.anthropic.com](https://console.anthropic.com) untuk fitur AI Brain

### Membuat Telegram Bot

1. Buka Telegram, cari **@BotFather**
2. Kirim `/newbot`
3. Ikuti instruksi: beri nama bot (misal: "SyamAdmin Server") dan username (misal: `syamadmin_vps1_bot`)
4. Catat **token** yang diberikan BotFather (format: `123456789:ABCdef...`)
5. Untuk mengetahui User ID Anda, buka **@userinfobot** dan kirim `/start` — catat angka **Id** yang ditampilkan

---

## 2. Instalasi

### Instalasi Cepat (One-Click)

Upload file `syamadmin.tar.gz` ke server, lalu jalankan:

```bash
# Upload dari komputer lokal
scp syamadmin.tar.gz root@IP_SERVER:~/

# SSH ke server
ssh root@IP_SERVER

# Extract dan install
tar xzf syamadmin.tar.gz
cd syamadmin
chmod +x install.sh
sudo ./install.sh
```

### Apa yang Dilakukan Installer

Installer melakukan langkah-langkah berikut secara otomatis:

1. Memverifikasi OS (Ubuntu 22.04/24.04)
2. Menginstall system dependencies: `python3`, `python3-venv`, `curl`, `wget`, `git`, `sqlite3`, `htop`, `rkhunter`, `lynis`
3. Membuat direktori kerja:
   - `/opt/syamadmin/` — kode program
   - `/etc/syamadmin/` — konfigurasi
   - `/var/log/syamadmin/` — log file
   - `/var/lib/syamadmin/` — database SQLite
4. Membuat Python virtual environment di `/opt/syamadmin/venv/`
5. Menginstall Python packages: `python-telegram-bot`, `anthropic`, `psutil`, `aiosqlite`, dll.
6. Mendaftarkan systemd service `syamadmin`
7. Mengkonfigurasi logrotate (rotasi log harian, retensi 14 hari)
8. Menginisialisasi database SQLite (tabel: `audit_log`, `metrics`, `sites`, `scheduled_tasks`, `alerts`)

---

## 3. Konfigurasi

Setelah instalasi, **wajib** edit file konfigurasi sebelum menjalankan agent:

```bash
sudo nano /etc/syamadmin/config.env
```

### Parameter Wajib

| Parameter | Contoh | Keterangan |
|-----------|--------|------------|
| `TELEGRAM_BOT_TOKEN` | `123456789:ABCdef...` | Token dari @BotFather |
| `TELEGRAM_ADMIN_ID` | `987654321` | Telegram User ID Anda (angka) |

### Parameter Opsional

| Parameter | Default | Keterangan |
|-----------|---------|------------|
| `ANTHROPIC_API_KEY` | *(kosong)* | API key untuk fitur AI Brain. Tanpa ini, `/ai` menggunakan keyword parser sederhana |
| `SERVER_NAME` | `my-vps-01` | Nama identitas server (ditampilkan di notifikasi) |
| `SERVER_TIMEZONE` | `Asia/Makassar` | Timezone server |
| `ALERT_THRESHOLD_CPU` | `85` | Alert jika CPU melebihi X% |
| `ALERT_THRESHOLD_RAM` | `90` | Alert jika RAM melebihi X% |
| `ALERT_THRESHOLD_DISK` | `85` | Alert jika disk melebihi X% |
| `ALERT_THRESHOLD_LOAD` | `4.0` | Alert jika load average melebihi X |
| `MONITOR_INTERVAL` | `60` | Interval monitoring dalam detik |
| `SSH_PORT` | `22` | Port SSH (digunakan oleh modul security & firewall) |
| `BACKUP_DIR` | `/var/backups/syamadmin` | Direktori penyimpanan backup |
| `BACKUP_RETENTION_DAYS` | `7` | Berapa hari backup disimpan sebelum dihapus otomatis |
| `PHP_VERSION` | `8.3` | Versi PHP yang diinstall oleh provisioner |
| `LOG_LEVEL` | `INFO` | Level logging: `DEBUG`, `INFO`, `WARNING`, `ERROR` |

### Contoh Konfigurasi Minimal

```env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrSTUvwxYZ
TELEGRAM_ADMIN_ID=987654321
ANTHROPIC_API_KEY=sk-ant-api03-xxxxx
SERVER_NAME=vps-nustek-01
SERVER_TIMEZONE=Asia/Makassar
```

---

## 4. Menjalankan Agent

### Start, Stop, dan Restart

```bash
# Aktifkan agar jalan otomatis saat boot + jalankan sekarang
sudo systemctl enable --now syamadmin

# Cek status
sudo systemctl status syamadmin

# Stop
sudo systemctl stop syamadmin

# Restart (setelah edit config)
sudo systemctl restart syamadmin
```

### Memantau Log

```bash
# Log real-time
sudo journalctl -u syamadmin -f

# Atau langsung dari file log
sudo tail -f /var/log/syamadmin/agent.log
```

### Verifikasi Agent Berjalan

Setelah agent dijalankan, buka Telegram dan kirim `/start` ke bot Anda. Anda akan menerima pesan:

```
🤖 SyamAdmin Agent
Server: vps-nustek-01
Status: 🟢 Online

Kirim /help untuk daftar perintah.
```

Anda juga akan menerima notifikasi startup otomatis:

```
🟢 SyamAdmin Agent Started
Server: vps-nustek-01
Status: Online & Ready
```

---

## 5. Perintah Telegram — Referensi Lengkap

### Monitoring & Status

**`/status`** — Menampilkan dashboard status server secara real-time.

Informasi yang ditampilkan: CPU usage (persentase + progress bar), load average (1/5/15 menit), RAM usage (used/total dalam GB), disk usage, statistik network (sent/received), jumlah process, dan uptime.

Contoh output:
```
🖥 Server Status
⏱ Uptime: 14d 6h 32m

CPU [████░░░░░░] 38%
Cores: 2 | Load: 0.45/0.38/0.31

RAM [██████░░░░] 62%
Used: 1.2/2.0 GB

Disk [███░░░░░░░] 34%
Used: 6.8/20.0 GB

Network
↑ Sent: 4521.3 MB | ↓ Recv: 12845.7 MB
Processes: 127
```

**`/services`** — Menampilkan status semua managed services.

Services yang dipantau: `nginx`, `mysql`, `php8.3-fpm`, `fail2ban`, `ufw`, `ssh`. Setiap service ditampilkan dengan indikator warna: 🟢 active, ⚫ inactive, 🔴 failed/error.

**`/logs [service]`** — Menampilkan 30 baris terakhir dari log file.

Service yang tersedia:

| Argumen | File Log |
|---------|----------|
| `nginx` | `/var/log/nginx/error.log` |
| `mysql` | `/var/log/mysql/error.log` |
| `auth` | `/var/log/auth.log` |
| `syslog` | `/var/log/syslog` (default) |
| `fail2ban` | `/var/log/fail2ban.log` |

Contoh: `/logs nginx` menampilkan 30 baris terakhir error log Nginx.

**`/audit`** — Menampilkan 15 entry terakhir dari audit log SyamAdmin. Setiap perintah yang dieksekusi oleh agent dicatat di sini beserta timestamp, modul, dan status (success/failed/blocked).

---

### Provisioning

**`/provision`** — Menginstall LEMP stack lengkap dari clean install.

Setelah mengirim perintah ini, agent akan meminta konfirmasi karena ini operasi besar. Kirim `/confirm provision` untuk melanjutkan.

Komponen yang diinstall:

1. **System update** — `apt update && upgrade`
2. **Nginx** — web server dengan konfigurasi yang sudah dioptimasi (gzip, security headers, worker tuning)
3. **MySQL 8** — database server, diamankan secara otomatis (hapus user anonymous, disable remote root, hapus test db). Password root digenerate random 24 karakter
4. **PHP 8.3** — dengan 15 extensions: `fpm`, `mysql`, `mbstring`, `xml`, `curl`, `gd`, `zip`, `intl`, `bcmath`, `redis`, `opcache`, `cli`, `common`, `tokenizer`. PHP.ini dioptimasi (upload 64MB, memory 256MB, max exec 60s)
5. **Composer** — dependency manager PHP
6. **Certbot** — SSL certificate manager (Let's Encrypt)
7. **Swap** — 2 GB swap file (jika belum ada), swappiness diset ke 10

Proses memakan waktu sekitar 5–10 menit. Progress dilaporkan step-by-step ke Telegram. Setelah selesai, Anda menerima laporan lengkap termasuk password MySQL root.

**Penting:** Password MySQL root disimpan di `/etc/syamadmin/config.env` dan `/root/.my.cnf`. Catat password ini di tempat aman.

---

### Site Management

**`/site add <domain> [framework]`** — Menambahkan site baru.

Contoh:
```
/site add example.com
/site add myapp.com laravel
```

Apa yang terjadi di belakang layar:
- Membuat direktori web: `/var/www/example.com/public_html/` (atau `/var/www/myapp.com/public/` untuk Laravel)
- Membuat halaman index default
- Generate konfigurasi Nginx vhost (PHP-FPM, security headers, caching static assets, `try_files` untuk clean URL)
- Membuat PHP-FPM pool terisolasi per site
- Enable site dan reload Nginx
- Menyimpan data site ke database

Jika Nginx config test gagal, perubahan di-rollback secara otomatis.

**`/site list`** — Menampilkan daftar semua site yang dikelola, termasuk status SSL dan path root.

**`/site ssl <domain>`** — Mengaktifkan SSL (HTTPS) via Let's Encrypt.

Prasyarat: domain sudah mengarah (DNS A record) ke IP server ini. Setelah SSL aktif:
- HTTP otomatis redirect ke HTTPS
- Auto-renewal certificate diaktifkan via certbot timer/cron
- Security headers HSTS ditambahkan

**`/site remove <domain>`** — Menghapus konfigurasi Nginx untuk sebuah domain. Direktori web **tidak** dihapus untuk keamanan — Anda harus menghapusnya manual jika diperlukan.

---

### Security & Hardening

**`/security`** — Menjalankan security audit komprehensif.

Audit memeriksa:
- SSH: apakah password authentication masih aktif
- SSH: apakah root login dengan password diizinkan
- Fail2Ban: status dan jumlah IP yang sedang di-ban
- UFW firewall: aktif atau tidak
- Unattended upgrades: sudah diinstall atau belum
- Port yang terbuka (listening)
- Package updates yang tersedia
- 5 login terakhir ke server

**`/harden`** — Menjalankan hardening menyeluruh dalam satu perintah.

Empat proses dijalankan berurutan:

1. **SSH Hardening:**
   - Port SSH sesuai konfigurasi
   - Root login: hanya via SSH key (prohibit-password)
   - Password authentication: dimatikan
   - Max auth tries: 3
   - Idle timeout: 5 menit (ClientAliveInterval 300s)
   - X11 forwarding, agent forwarding, TCP forwarding: dimatikan

2. **Fail2Ban Setup:**
   - SSH jail: 3 percobaan → ban 2 jam
   - Nginx HTTP auth: 3 percobaan → ban 1 jam
   - Nginx bot search: aktif
   - Nginx rate limit: aktif

3. **Firewall Defaults:**
   - Default policy: deny incoming, allow outgoing
   - Port yang dibuka: SSH, 80 (HTTP), 443 (HTTPS)

4. **Auto Security Updates:**
   - Install dan aktifkan `unattended-upgrades`

**Peringatan:** Sebelum menjalankan `/harden`, pastikan Anda sudah menambahkan SSH public key ke server. Jika password authentication dimatikan tanpa SSH key terpasang, Anda bisa terkunci dari server.

---

### Firewall

**`/firewall`** — Menampilkan status UFW dan semua rule yang aktif.

**`/fw allow <port>`** — Membuka port untuk incoming traffic. Contoh: `/fw allow 3306` membuka port MySQL.

**`/fw deny <port>`** — Memblokir port. Contoh: `/fw deny 8080`.

**`/fw rules`** — Menampilkan semua rule dengan nomor urut (berguna untuk menghapus rule tertentu).

Semua operasi firewall menggunakan protokol TCP secara default.

---

### Backup

**`/backup`** — Menjalankan full backup (database + files).

**`/backup db`** — Backup semua database MySQL saja. Output: file `.sql.gz` terkompresi di `/var/backups/syamadmin/db/`.

**`/backup files`** — Backup file web dan konfigurasi. Direktori yang di-backup: `/var/www/`, `/etc/nginx/`, `/etc/php/`. Output: file `.tar.gz` di `/var/backups/syamadmin/files/`.

**`/backup list`** — Menampilkan daftar semua backup yang tersedia, diurutkan dari yang terbaru, beserta ukuran file dan tanggal pembuatan.

Backup lama dihapus otomatis setelah melewati periode retensi (default: 7 hari, dikonfigurasi via `BACKUP_RETENTION_DAYS`).

---

### AI Brain

**`/ai <perintah dalam bahasa bebas>`** — Mengirim perintah dalam bahasa Indonesia atau Inggris yang akan diproses oleh AI.

AI Brain menerjemahkan perintah natural language menjadi aksi terstruktur, lalu menjalankannya melalui modul yang tepat. Fitur ini memerlukan `ANTHROPIC_API_KEY` di konfigurasi. Tanpa API key, fallback ke keyword parser sederhana.

Contoh perintah yang dipahami:

```
/ai restart nginx
/ai cek kenapa disk penuh
/ai tambah site portal.desa.id dengan framework laravel
/ai install redis-server
/ai buka port 6379 di firewall
/ai backup database sekarang
/ai scan rootkit
/ai update semua package
/ai lihat siapa saja yang login hari ini
/ai analisis error log nginx
```

Jika AI mendeteksi perintah yang berisiko (misalnya menghapus data atau mengubah konfigurasi kritis), agent akan meminta konfirmasi sebelum mengeksekusi. Anda bisa mengetik `ya`, `yes`, `ok`, `lanjut`, atau `confirm` untuk melanjutkan.

Perintah yang tidak dikenali akan mendapat respons berupa saran perintah yang tersedia.

**Pesan teks bebas (tanpa `/ai`)** — Anda juga bisa mengetik perintah langsung tanpa awalan `/ai`. Semua pesan teks non-command secara otomatis dialihkan ke AI Brain.

---

### Utility

**`/start`** — Menampilkan pesan selamat datang dan status agent.

**`/help`** — Menampilkan ringkasan semua perintah yang tersedia.

**`/confirm <action>`** — Mengkonfirmasi aksi yang memerlukan persetujuan (provision, perintah AI berisiko). Konfirmasi berlaku selama 2 menit setelah diminta.

---

## 6. Alur Kerja Umum

### Skenario 1: Setup Server Baru dari Nol

```
Anda  → /start
Bot   → 🤖 SyamAdmin Agent — Server: vps-01 — Status: 🟢 Online

Anda  → /provision
Bot   → ⚠️ Provisioning LEMP Stack...
         Kirim /confirm provision untuk melanjutkan.

Anda  → /confirm provision
Bot   → 🚀 Memulai instalasi LEMP stack...
         📦 [1/7] Updating system packages...
         🌐 [2/7] Installing Nginx...
         🗄 [3/7] Installing MySQL 8...
         🐘 [4/7] Installing PHP 8.3...
         🎼 [5/7] Installing Composer...
         🔒 [6/7] Installing Certbot...
         💾 [7/7] Configuring swap...
         ✅ LEMP Stack Installation Complete
         🔑 MySQL root password: xK7#mP...

Anda  → /harden
Bot   → 🔐 SSH Hardened + Fail2Ban Active + Firewall Ready

Anda  → /site add portal.desa.id laravel
Bot   → ✅ Site portal.desa.id berhasil ditambahkan!

Anda  → /site ssl portal.desa.id
Bot   → ✅ SSL aktif untuk portal.desa.id!

Anda  → /status
Bot   → 🖥 Server Status [dashboard lengkap]
```

### Skenario 2: Monitoring Harian

Anda tidak perlu melakukan apa-apa secara aktif. Agent secara otomatis:

- Mengecek CPU, RAM, disk, load setiap 60 detik
- Mengecek status services (nginx, mysql, php-fpm, fail2ban, ufw, ssh)
- Mengirim alert jika ada threshold yang terlampaui
- Mengirim alert jika ada service yang down

Jika ingin cek manual:
```
/status      → dashboard ringkas
/services    → status per service
/logs nginx  → error log terbaru
```

### Skenario 3: Menambah Site Baru

```
/site add toko.example.com
/site ssl toko.example.com
```

Lalu upload file aplikasi Anda ke `/var/www/toko.example.com/public_html/`.

### Skenario 4: Insiden — Disk Penuh

```
Bot   → 🔴 Alert — CRITICAL
         Module: monitor
         Disk hampir penuh: 92% (18.4/20.0 GB)

Anda  → /ai cek folder apa yang paling banyak makan disk
Bot   → [menjalankan du -sh /* dan melaporkan hasilnya]

Anda  → /ai hapus log lama di /var/log yang lebih dari 7 hari
Bot   → ⚠️ Konfirmasi Diperlukan...

Anda  → ya
Bot   → ✅ Log lama dibersihkan. Disk usage turun ke 61%.
```

---

## 7. Sistem Monitoring & Alert

### Bagaimana Monitoring Bekerja

Agent menjalankan background loop yang mengumpulkan metrik sistem setiap `MONITOR_INTERVAL` detik (default: 60). Metrik disimpan ke database SQLite untuk analisis tren.

### Threshold Alert

| Metrik | Default | Severity | Pesan |
|--------|---------|----------|-------|
| CPU > X% | 85% | warning | Menampilkan top processes penyebab |
| RAM > X% | 90% | warning | Menampilkan used/total |
| Disk > X% | 85% | critical | Menampilkan used/total |
| Load > X | 4.0 | warning | Menampilkan load average |
| Service down | — | critical | Menyarankan command untuk restart |

### Alert Cooldown

Untuk menghindari spam notifikasi, alert yang sama tidak akan dikirim ulang dalam waktu 5 menit. Jika CPU tetap tinggi selama 10 menit, Anda menerima 2 alert (bukan 10).

### Service Monitoring

Setiap loop, agent juga mengecek apakah managed services masih running. Jika salah satu service down dan service tersebut memang terinstall di server, alert dikirim dengan saran perintah restart.

---

## 8. Keamanan & Hardening

### Lapisan Keamanan yang Diterapkan

Setelah menjalankan `/harden`, server Anda memiliki:

**SSH:**
- Password authentication dimatikan (hanya SSH key)
- Root login hanya via key
- Maksimal 3 percobaan login
- Sesi idle otomatis disconnect setelah 5 menit
- X11 forwarding, agent forwarding, TCP forwarding dimatikan

**Fail2Ban:**
- SSH brute force protection (3 attempts → ban 2 jam)
- Nginx HTTP auth protection
- Nginx bot search detection
- Nginx rate limit enforcement

**Firewall (UFW):**
- Default deny semua incoming traffic
- Hanya port SSH, HTTP (80), HTTPS (443) yang dibuka
- Rate limiting bisa ditambahkan per port

**Nginx:**
- Server tokens disembunyikan (`server_tokens off`)
- Security headers: X-Frame-Options, X-Content-Type-Options, X-XSS-Protection, Referrer-Policy
- Dengan SSL: HSTS header, TLS 1.2/1.3 only, cipher suite modern
- Hidden files (`.env`, `.git`) di-deny

**PHP:**
- `X-Powered-By` header disembunyikan

### Audit Berkala

Disarankan menjalankan `/security` secara berkala (minimal mingguan) untuk memastikan semua konfigurasi keamanan masih intact, memeriksa updates yang tersedia, dan memantau login history.

---

## 9. Manajemen Site & SSL

### Struktur Direktori Site

Setiap site yang ditambahkan memiliki struktur berikut:

```
/var/www/example.com/
└── public_html/          ← document root (default)
    └── index.html        ← halaman default

# Untuk framework Laravel:
/var/www/myapp.com/
├── public/               ← document root (Laravel)
│   └── index.php
├── app/
├── config/
├── ...
```

### Konfigurasi Nginx yang Digenerate

Setiap vhost sudah dikonfigurasi dengan:

- PHP-FPM via Unix socket
- Security headers
- Static asset caching (30 hari untuk images, CSS, JS, fonts)
- Hidden file denial (`.env`, `.git`, `.htaccess`)
- Clean URL support (`try_files $uri $uri/ /index.php?$query_string`) — kompatibel dengan Laravel, WordPress, dan framework PHP lainnya

### SSL Certificate

SSL menggunakan Let's Encrypt via Certbot dan dikonfigurasi dengan:

- Auto-redirect HTTP ke HTTPS
- TLS 1.2 dan 1.3
- HSTS header (max-age 2 tahun)
- OCSP stapling
- Auto-renewal via certbot timer

Pastikan DNS A record domain sudah mengarah ke IP server sebelum mengaktifkan SSL. Certbot akan gagal jika domain belum bisa diakses.

---

## 10. Backup & Restore

### Lokasi Backup

Semua backup disimpan di `/var/backups/syamadmin/` (atau sesuai `BACKUP_DIR`):

```
/var/backups/syamadmin/
├── db/
│   └── all_databases_20260531_020000.sql.gz
└── files/
    └── webfiles_20260531_020030.tar.gz
```

### Database Backup

`/backup db` menjalankan `mysqldump` dengan opsi:
- `--all-databases` — semua database
- `--single-transaction` — konsisten tanpa lock (InnoDB)
- `--routines --triggers` — termasuk stored procedures dan triggers
- Output dikompresi dengan gzip

### File Backup

`/backup files` membuat archive tar.gz yang berisi:
- `/var/www/` — semua file web
- `/etc/nginx/` — konfigurasi Nginx
- `/etc/php/` — konfigurasi PHP

### Restore Manual

Untuk restore database:
```bash
gunzip < /var/backups/syamadmin/db/all_databases_20260531_020000.sql.gz | mysql -u root
```

Untuk restore files:
```bash
tar xzf /var/backups/syamadmin/files/webfiles_20260531_020030.tar.gz -C /
```

### Retensi Otomatis

Backup yang lebih lama dari `BACKUP_RETENTION_DAYS` (default: 7 hari) dihapus otomatis setiap kali full backup dijalankan.

---

## 11. AI Brain — Perintah Natural Language

### Cara Kerja

Ketika Anda mengirim `/ai <perintah>`, alurnya:

1. Agent mengumpulkan konteks server terkini (CPU, RAM, disk, load, uptime)
2. Perintah + konteks dikirim ke Claude API
3. Claude menganalisis intent dan menentukan modul + aksi yang tepat
4. Hasil dikembalikan dalam format terstruktur (modul, aksi, parameter)
5. Agent mengeksekusi aksi tersebut melalui modul yang ditentukan
6. Hasil eksekusi dilaporkan ke Telegram

### Modul yang Bisa Dipanggil AI

| Modul | Contoh Aksi | Contoh Perintah |
|-------|-------------|-----------------|
| provisioner | `install_lemp`, `install_package` | "install redis-server" |
| security | `harden_ssh`, `audit`, `scan_rootkit`, `check_updates` | "scan rootkit", "cek update" |
| firewall | `allow_port`, `deny_port`, `status`, `list_rules` | "buka port 6379" |
| monitor | `status`, `services`, `disk_usage` | "cek status server" |
| site_manager | `add_site`, `remove_site`, `enable_ssl`, `list_sites` | "tambah site baru.com" |
| backup | `backup_db`, `backup_files`, `backup_all`, `list_backups` | "backup database sekarang" |
| executor | `run_command`, `service_restart` | "restart php-fpm" |

### Konfirmasi Perintah Berisiko

AI akan meminta konfirmasi jika perintah terdeteksi berisiko, misalnya menghapus data, mengubah konfigurasi kritis, atau menjalankan shell command langsung. Anda harus mengkonfirmasi dalam 2 menit.

### Fallback Mode

Jika `ANTHROPIC_API_KEY` tidak diset, AI Brain menggunakan keyword parser sederhana. Perintah-perintah dasar seperti "status", "restart nginx", "backup", "firewall" tetap bisa dikenali, namun kemampuan memahami konteks dan perintah kompleks terbatas.

---

## 12. Struktur File & Direktori

### File Program

```
/opt/syamadmin/
├── syamadmin.py             # Entry point daemon
├── venv/                    # Python virtual environment
├── modules/
│   ├── brain.py             # AI decision engine
│   ├── telegram_bot.py      # Telegram interface
│   ├── provisioner.py       # LEMP stack installer
│   ├── security.py          # Hardening & audit
│   ├── firewall.py          # UFW manager
│   ├── monitor.py           # System metrics & alerts
│   ├── site_manager.py      # Nginx vhost & SSL
│   ├── backup.py            # Backup engine
│   ├── notifier.py          # Telegram notification
│   └── executor.py          # Safe shell executor + audit
├── templates/
│   ├── nginx_vhost.conf     # Template vhost HTTP
│   ├── nginx_ssl.conf       # Template vhost HTTPS
│   └── php_fpm_pool.conf    # Template PHP-FPM pool
└── scripts/
    ├── harden_ssh.sh
    ├── setup_fail2ban.sh
    └── setup_swap.sh
```

### File Konfigurasi & Data

```
/etc/syamadmin/config.env         # Konfigurasi (chmod 600)
/var/log/syamadmin/agent.log      # Log agent
/var/lib/syamadmin/syamadmin.db   # Database SQLite
/var/backups/syamadmin/           # Direktori backup
```

### Systemd Service

```
/etc/systemd/system/syamadmin.service
```

---

## 13. Troubleshooting

### Agent Tidak Merespons di Telegram

1. Cek apakah service berjalan:
   ```bash
   sudo systemctl status syamadmin
   ```

2. Cek log untuk error:
   ```bash
   sudo journalctl -u syamadmin -n 50
   ```

3. Pastikan `TELEGRAM_BOT_TOKEN` benar di config
4. Pastikan `TELEGRAM_ADMIN_ID` sesuai User ID Anda (bukan username)
5. Restart agent:
   ```bash
   sudo systemctl restart syamadmin
   ```

### "Unauthorized" Saat Kirim Perintah

Hanya user dengan ID yang cocok dengan `TELEGRAM_ADMIN_ID` yang diizinkan menggunakan bot. Verifikasi User ID Anda via @userinfobot.

### Provision Gagal di Tengah Jalan

- Cek log: `sudo tail -100 /var/log/syamadmin/agent.log`
- Cek `apt` lock: `sudo rm /var/lib/dpkg/lock-frontend 2>/dev/null; sudo dpkg --configure -a`
- Jalankan ulang `/provision` — komponen yang sudah terinstall akan di-skip

### SSL Gagal

Penyebab umum:
- DNS belum propagasi (cek: `dig +short example.com` harus mengembalikan IP server)
- Port 80 diblokir firewall (`/fw allow 80`)
- Rate limit Let's Encrypt (maksimal 5 certificate per domain per minggu)

### AI Brain Error

- Pastikan `ANTHROPIC_API_KEY` valid dan memiliki kredit
- Cek di log apakah ada error API
- AI Brain otomatis fallback ke keyword parser jika API gagal

### Agent Crash Loop (Restart Terus)

```bash
# Cek log
sudo journalctl -u syamadmin -n 100 --no-pager

# Disable sementara untuk debug
sudo systemctl stop syamadmin

# Jalankan manual untuk lihat error langsung
sudo /opt/syamadmin/venv/bin/python3 /opt/syamadmin/syamadmin.py
```

### Database Corrupt

```bash
# Backup dulu
cp /var/lib/syamadmin/syamadmin.db /var/lib/syamadmin/syamadmin.db.bak

# Cek integrity
sqlite3 /var/lib/syamadmin/syamadmin.db "PRAGMA integrity_check;"

# Jika corrupt, buat baru (data historis hilang, tapi agent tetap jalan)
rm /var/lib/syamadmin/syamadmin.db
sudo systemctl restart syamadmin
```

---

## 14. Keamanan Agent

### Command Safety

Setiap shell command yang dieksekusi oleh SyamAdmin melewati safety filter. Perintah berbahaya berikut **diblokir secara permanen** dan tidak bisa dieksekusi melalui cara apapun:

- `rm -rf /` dan variasi perusakan filesystem
- `mkfs.` (format disk)
- Penulisan langsung ke `/dev/sda`
- Fork bomb (`:(){:|:&};:`)
- `chmod -R 777 /`
- Piped execution dari internet (`curl | bash`, `wget | bash`)

### Audit Trail

Setiap perintah yang dieksekusi dicatat di database audit log dengan: timestamp, modul pemanggil, perintah yang dijalankan, durasi eksekusi, user ID, dan status (success/failed/blocked/timeout).

Lihat audit log via `/audit` di Telegram atau langsung query database:
```bash
sqlite3 /var/lib/syamadmin/syamadmin.db \
  "SELECT timestamp, module, action, status FROM audit_log ORDER BY id DESC LIMIT 20;"
```

### File Permission

- `/etc/syamadmin/config.env` — mode `600` (hanya root yang bisa baca, berisi token dan password)
- Agent berjalan sebagai root (diperlukan untuk manajemen service dan package)
- Database di `/var/lib/syamadmin/` — mode `755`

### Bot Telegram

- Hanya satu admin (berdasarkan User ID numerik) yang bisa mengontrol bot
- Percobaan akses dari user lain di-log sebagai security event
- Operasi berbahaya memerlukan konfirmasi eksplisit dengan timeout 2 menit

---

## 15. Tips Operasional

### Setelah Install Pertama Kali

1. Jalankan `/provision` untuk setup LEMP stack
2. Jalankan `/harden` untuk security hardening
3. Jalankan `/security` untuk audit awal
4. Simpan password MySQL root di password manager

### Rutinitas Harian

Tidak perlu melakukan apa-apa — agent memantau dan mengirim alert secara otomatis. Jika ingin cek proaktif, gunakan `/status`.

### Rutinitas Mingguan

- `/security` — cek audit keamanan
- `/backup` — trigger full backup manual (di samping scheduled backup)
- Review alert yang muncul selama seminggu

### Sebelum Deploy Aplikasi Baru

```
/site add newapp.com laravel     # buat site
/site ssl newapp.com             # aktifkan SSL
/fw allow 6379                   # buka port jika perlu (Redis, dsb.)
```

Upload kode, set permission, selesai.

### Mengubah Konfigurasi Agent

Setelah mengedit `/etc/syamadmin/config.env`, restart agent:
```bash
sudo systemctl restart syamadmin
```

### Mengupdate Agent

Upload versi baru file-file ke `/opt/syamadmin/`, lalu restart:
```bash
sudo systemctl restart syamadmin
```

Virtual environment dan database tidak perlu disentuh — hanya file Python yang perlu diupdate.

---

*SyamAdmin — dibuat untuk menyederhanakan hidup sysadmin.*
