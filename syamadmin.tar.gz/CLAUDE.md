# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Project Is

**SyamAdmin** is an AI-powered sysadmin daemon for Ubuntu 22.04 VPS, controlled entirely through Telegram. It provisions LEMP stacks, manages Nginx sites/SSL, hardens SSH, manages UFW firewall, runs backups, and monitors system health — all via chat commands in Indonesian or English.

The agent runs as a `systemd` service on the VPS itself. Development happens here on macOS; deployment is via `scp` + `install.sh` to a remote Ubuntu server.

## Running the Agent

The agent is **not meant to run locally** — it requires Ubuntu system utilities (`systemctl`, `ufw`, `certbot`, `mysql`, etc.). To run it:

```bash
# On the target Ubuntu VPS after install:
sudo systemctl start syamadmin
sudo systemctl status syamadmin
sudo journalctl -u syamadmin -f          # tail live logs

# Debug mode (run directly, see all output):
sudo /opt/syamadmin/venv/bin/python3 /opt/syamadmin/syamadmin.py

# Query the audit database directly:
sqlite3 /var/lib/syamadmin/syamadmin.db \
  "SELECT timestamp, module, action, status FROM audit_log ORDER BY id DESC LIMIT 20;"
```

## Deploying Changes

```bash
# Re-package and upload to VPS:
# IMPORTANT: exclude scratch/ (contains local config.env with real secrets),
# venv, *.db, and caches — otherwise credentials leak into the package.
tar czf syamadmin.tar.gz \
  --exclude='.git' --exclude='*.tar.gz' --exclude='scratch' \
  --exclude='venv' --exclude='*.db' --exclude='__pycache__' \
  --exclude='*.pyc' --exclude='.claude' --exclude='.DS_Store' .
scp syamadmin.tar.gz root@YOUR_IP:~/

# On VPS: extract and overwrite, then restart:
tar xzf syamadmin.tar.gz -C /opt/syamadmin --strip-components=1
sudo systemctl restart syamadmin
```

**In-band self-update**: once deployed, releases can be pulled from GitHub via Telegram with `/update` (`/update check` then `/update now`). It downloads the branch tarball (`UPDATE_BRANCH`, default `main`) from `GITHUB_REPO` (default `Syamsuddin/SyamAdmin`), runs the detached `scripts/update.sh` (backup → `cp -a` over `/opt/syamadmin` keeping `venv`/config/db → `pip install -r requirements.txt` → restart → health-check → auto-rollback on failure). Bump the root `VERSION` file on every release so the check detects it. `/sysupdate` is the separate OS-package (`apt`) updater.

## Architecture

The agent has three concurrent async tasks running in `syamadmin.py`:
1. **`SyamAdminBot`** — Telegram polling loop (command router)
2. **`SystemMonitor`** — Background metrics collection + threshold alerts
3. **`PreEmptiveFirewall`** (PeFi) — Traffic collection, anomaly detection, AI-driven blocking

All user interactions flow:
```
Telegram message → SyamAdminBot (command/text handler)
                 → AIBrain.process_command()  [native tool-use; injects Memory Core:
                                                server-state + user prefs + chat history + lessons]
                 → single action via _execute_ai_action()
                   OR multi-step plan via _execute_multi_step_plan()  [if AI returns steps]
                 → specific module method
                 → CommandExecutor.run()       [shell execution, safety filter]
                 → SQLite audit_log            [every command logged]
                 → Notifier.send() / _reply()/_edit()  [Telegram reply, Markdown-safe w/ plaintext fallback]
```

## Module Responsibilities

| Module | File | Purpose |
|--------|------|---------|
| `SyamAdminBot` | `modules/telegram_bot.py` | Command handlers, confirmation flow, free-text AI routing, multi-step orchestrator, enriched `/status` |
| `AIBrain` | `modules/brain.py` | Claude API (native tool-use) → structured action(s); Memory Core (user prefs, chat history, lessons via FTS5); secret redaction; keyword fallback when no API key |
| `CommandExecutor` | `modules/executor.py` | Async shell execution, safety filter (regex + shlex tokenization), SQLite audit log |
| `SystemMonitor` | `modules/monitor.py` | Metrics loop, threshold alerts (dedup cooldown), service health checks, DB retention/pruning, server state context |
| `Notifier` | `modules/notifier.py` | Telegram message sender (used by modules to push alerts) |
| `Provisioner` | `modules/provisioner.py` | LEMP stack installer |
| `SecurityManager` | `modules/security.py` | SSH hardening, Fail2Ban, rootkit scan, auto-updates |
| `FirewallManager` | `modules/firewall.py` | UFW rule management |
| `SiteManager` | `modules/site_manager.py` | Nginx vhosts, PHP-FPM pools, Let's Encrypt SSL |
| `BackupManager` | `modules/backup.py` | MySQL dump, file tar, retention cleanup |
| `Updater` | `modules/updater.py` | Self-update from GitHub (tarball): version check (`VERSION` vs `raw.githubusercontent`) + trigger detached `scripts/update.sh` |

## Key Design Patterns

**Confirmation flow**: Dangerous operations set a pending confirmation in `_pending_confirmations[admin_id]` (60–120s expiry). Two-tier confirmation:
- **Non-destructive actions** (`ai`, `add_cron`, `optimize_system`): accept affirmative words (`ya/iya/ok/oke/yes/y/lanjut/setuju/gas`) OR the numeric OTP code.
- **Destructive actions** (`provision`, `remove_site`, `deny_ssh`, `change_ssh_port`, `restore`, `repair_service`, `wizard_provision`): strictly require the OTP code. Affirmative words are rejected.
- **AI `run_command`**: any free shell command the AI emits is force-flagged `destructive` (strict OTP) regardless of the model's `confirmation_needed` — the static safety filter alone is not trusted for destructive-but-unblocked commands.
- **Multi-step plans** (action `plan`): a plan requires OTP if ANY step is not in `SAFE_READONLY_ACTIONS` (allowlist, not blocklist — model action names vary).

**Safety filter**: `CommandExecutor._is_blocked()` checks every shell command (regex blacklist + `shlex` tokenization, incl. nested interpreters) before execution. Cannot be bypassed — runs before every `executor.run()`/`run_exec()` call.

**AI Brain tool-use contract**: `AIBrain.process_command(user_message, context, history)` uses native Anthropic **tool-use** (`DISPATCH_TOOL`) — no fragile JSON-in-text parsing. Returns a dict with keys `intent`, `module`, `action`, `params`, `confirmation_needed`, `message`, and optionally `steps` (array of `{module, action, params, message}`) for compound commands. The `_execute_ai_action()` method routes single actions via `ACTION_ALIASES` + `getattr(module, action)(**params)`; `_execute_multi_step_plan()` runs `steps` sequentially with live progress, halt-on-failure, and `learn_lesson()` on success.

**Memory Core** (`AIBrain`, SQLite): Pilar 2 `user_memory` (prefs), Pilar 3 `chat_history` (8-turn sliding window, sent as message turns), Pilar 4 `long_term_memory` (FTS5 relevance search). `redact_secrets()` strips keys/tokens/passwords before any persist. Pilar 1 (server state) comes from `monitor.get_state_context()`.

**Profil & konteks waktu** (`AIBrain`): `user_memory` also hosts the admin profile (`profile.*` keys: name/nickname/job/organization/location/timezone/language/hobby/comm_style) and server context (`server.*`: role/purpose), defined by the `PROFILE_FIELDS` schema. `get_user_preferences()` excludes these prefixes; they are surfaced separately via `get_profile_context()`. `get_system_context()` injects real date/time/day in the admin's timezone (`profile.timezone` → env `TZ` → `Asia/Jakarta`) — volatile, never cached. Both are prepended to the AI context in `cmd_ai`. Onboarding: the `/profile` command (show / `setup` wizard / `set <field> <val>` / `reset`) plus an auto-offer on `/start` and the startup notification when the profile is empty. The `PROFILE` wizard state lives in `_wizard_states` (same pattern as the site/setup wizards).

**Prompt caching**: only the static prefix (system + tools) carries `cache_control: ephemeral`. Volatile content (history/prefs) goes in `messages`, never cached. Engages on Sonnet/Opus (≥1024-token min); inert on Haiku (2048 min) at current prefix size (~1470 tokens).

**Markdown-safe send**: `_reply()`/`_edit()` (bot) and `Notifier.send()` retry as plain text if Telegram rejects malformed Markdown (400) — messages are never lost silently.

**Module wiring**: All modules are instantiated in `syamadmin.py:main()` and passed into the bot as a `modules` dict. Modules receive `executor` and `notifier` at construction time.

**Bilingual support**: Bot messages and the AI system prompt are in Indonesian (`id`). The Claude model defaults to `claude-haiku-4-5-20251001`, overridable via the `CLAUDE_MODEL` env var.

## Configuration

Config lives at `/etc/syamadmin/config.env` on the VPS (permissions `600`). Template: `config.env.example`. Required vars: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_ADMIN_ID`. All others have defaults.

The daemon reads config via `python-dotenv` with `override=True` — the config file is authoritative over inherited shell env (prevents a stale `ANTHROPIC_API_KEY` in the shell from shadowing the configured one). A `CONFIG_PATH` env override points to a different file (useful for testing).

Notable optional vars: `CLAUDE_MODEL` (default `claude-haiku-4-5-20251001`), `METRICS_RETENTION_DAYS` (30), `AUDIT_RETENTION_DAYS` (90), `CHAT_HISTORY_RETENTION_DAYS` (14), `LONG_TERM_MEMORY_MAX_ROWS` (1000).

## SQLite Schema

The database at `/var/lib/syamadmin/syamadmin.db`. Each module ensures its own tables idempotently in `_ensure_db()` (self-sufficient — no longer depends on `install.sh` seeding):
- `audit_log` (executor) — every shell command with timestamp, module, action, status
- `token_usage` (brain) — AI token consumption + cost
- `user_memory` (brain) — admin preferences (Pilar 2) + admin profile (`profile.*`) & server context (`server.*`)
- `chat_history` (brain) — conversation turns, redacted (Pilar 3)
- `long_term_memory` + `long_term_fts` FTS5 (brain) — incident/config lessons (Pilar 4)
- `metrics` (monitor) — historical resource snapshots
- `sites` (site_manager) — managed Nginx virtual hosts

Old data is pruned periodically by `SystemMonitor._prune_old_data()` (once/24h).

## Nginx / PHP Templates

`templates/nginx_vhost.conf` and `templates/nginx_ssl.conf` are Jinja-style templates with `{domain}`, `{webroot}`, `{php_version}` placeholders. `SiteManager` reads and renders these via `.format()` or string replacement — check the actual implementation before editing placeholders.